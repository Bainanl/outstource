<template>
  <div>
    
  </div>
</template>

<script lang="js">
import { defineComponent } from 'vue'
export default defineComponent({
  setup() {

  }
})
</script>

<style lang="scss" scoped>
  
</style>