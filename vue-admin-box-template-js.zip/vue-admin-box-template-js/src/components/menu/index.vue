<template>
  <router-view></router-view>
</template>

<script lang="js">
import { defineComponent } from 'vue'
export default defineComponent({
  setup() {

  }
})
</script>