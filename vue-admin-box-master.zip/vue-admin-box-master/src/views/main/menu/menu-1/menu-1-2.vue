<template>
  <el-card class="box-card">
    <p>我是三级导航菜单1-2</p>
  </el-card>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
export default defineComponent({
  setup() {

  }
})
</script>

<style lang="scss" scoped>
  .box-card {
    margin: 15px;
  }
</style>