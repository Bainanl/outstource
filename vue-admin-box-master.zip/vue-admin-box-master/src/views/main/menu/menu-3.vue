<template>
  <el-card class="box-card">
    <p>我是二级导航菜单3</p>
  </el-card>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
export default defineComponent({
  setup() {

  }
})
</script>

<style lang="scss" scoped>
  .box-card {
    margin: 15px;
  }
</style>