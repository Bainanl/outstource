<template>
  <el-container style="height: 100vh">
    <Header />
  </el-container>
</template>

<script lang="ts" setup>
import Header from './Header/index.vue'
</script>

<style lang="scss" scoped>
  
</style>