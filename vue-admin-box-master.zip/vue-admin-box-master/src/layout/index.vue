<template>
  <div>
    <Theme1 />
  </div>
</template>

<script lang="ts" setup>
import Theme1 from './theme1/index.vue'
import Theme2 from './theme2/index.vue'
</script>

<style lang="scss" scoped>
  
</style>