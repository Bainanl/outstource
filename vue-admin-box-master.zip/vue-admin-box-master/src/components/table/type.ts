export interface Page{
  index: number,
  size: number,
  total: number
}